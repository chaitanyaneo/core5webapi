﻿using Riktam.DAL.Interface;
using Riktam.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Riktam.BAL.Service
{
    public class UserService
    {
        private readonly IRepository<User> _User;

        public UserService(IRepository<User> User)
        {
            _User = User;
        }
        //Get User Details By User Id
        public IEnumerable<User> GetUserByUserId(string UserId)
        {
            return _User.GetAll().Where(x => x.UserEmail == UserId).ToList();
        }
        //GET All User Details 
        public IEnumerable<User> GetAllUsers()
        {
            try
            {
                return _User.GetAll().ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        //Get User by User Name
        public User GetUserByUserName(string UserName)
        {
            return _User.GetAll().Where(x => x.UserEmail == UserName).FirstOrDefault();
        }
        //Add User
        public async Task<User> AddUser(User User)
        {
            return await _User.Create(User);
        }
        //Delete User 
        public bool DeleteUser(string UserEmail)
        {

            try
            {
                var DataList = _User.GetAll().Where(x => x.UserEmail == UserEmail).ToList();
                foreach (var item in DataList)
                {
                    _User.Delete(item);
                }
                return true;
            }
            catch (Exception)
            {
                return true;
            }

        }
        //Update User Details
        public bool UpdateUser(User User)
        {
            try
            {
                var DataList = _User.GetAll().Where(x => x.IsDeleted != true).ToList();
                foreach (var item in DataList)
                {
                    _User.Update(item);
                }
                return true;
            }
            catch (Exception)
            {
                return true;
            }
        }
    }
}