﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Riktam.DAL.Models
{
    [Table("GroupMessages", Schema = "dbo")]
    public class GroupMessage
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Message")]
        public string Message { get; set; }

        // Foreign key to Group
        [ForeignKey("Groups")]
        public int GroupId { get; set; }
        public Group Group { get; set; }


        // Foreign key to User
        [ForeignKey("Users")]
        public int UserId { get; set; }
        public User User { get; set; }
    }
}
