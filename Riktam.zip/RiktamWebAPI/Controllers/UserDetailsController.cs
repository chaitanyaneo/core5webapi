﻿using Riktam.BAL.Service;
using Riktam.DAL.Interface;
using Riktam.DAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;

namespace Riktam.WebApi.Controllers
{
   

    [Route("api/[controller]")]
    [ApiController]
    public class UserDetailsController : ControllerBase
    {
        private readonly UserService _UserService;
        private readonly IConfiguration _config;
        private readonly ITokenService _tokenService;
        private string generatedToken = null;

        public UserDetailsController(IConfiguration config, ITokenService tokenService, UserService userService)
        {
            _config = config;
            _tokenService = tokenService;
            _UserService = userService;
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<Object> Login(UserModel userModel)
        {
            if (string.IsNullOrEmpty(userModel.UserName) || string.IsNullOrEmpty(userModel.Password))
            {
                return BadRequest("Please pass the valid Username and Password");
            }

            IActionResult response = Unauthorized();
            var validUser = GetUser(userModel);

            if (validUser != null && validUser.UserPassword == userModel.Password)
            {
                generatedToken = _tokenService.BuildToken(_config["Jwt:Key"].ToString(), _config["Jwt:Issuer"].ToString(),
                validUser);

                if (generatedToken != null)
                {
                    HttpContext.Session.SetString("Token", generatedToken);
                    var tokenString = GenerateJwtToken(userModel.UserName);
                    return Ok(new { Token = tokenString, Message = "Success" });
                }
                else
                {
                    return BadRequest("Unable to generate token");
                }
            }
            else
            {
                return BadRequest("Please pass the valid Username and Password");
            }
        }


        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet(nameof(GetResult))]
        public IActionResult GetResult()
        {
            return Ok("API Validated");
        }
        /// <summary>
        /// Generate JWT Token after successful login.
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        private string GenerateJwtToken(string userName)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_config["Jwt:key"]);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim("id", userName) }),
                Expires = DateTime.UtcNow.AddHours(1),
                Issuer = _config["Jwt:Issuer"],
                Audience = _config["Jwt:Audience"],
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
        private User GetUser(UserModel userModel)
        {
            //Write your code here to authenticate the user
            return _UserService.GetUserByUserName(userModel.UserName);
        }

        //Add User
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("AddUser")]
        public async Task<Object> AddUser([FromBody] User User)
        {
            try
            {
                await _UserService.AddUser(User);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        //Delete User
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeleteUser")]
        public bool DeleteUser(string UserEmail)
        {
            try
            {
                _UserService.DeleteUser(UserEmail);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        //Delete User
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [HttpPut("UpdateUser")]
        public bool UpdateUser(User Object)
        {
            try
            {
                _UserService.UpdateUser(Object);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        //GET All User by Name
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetAllUserByName")]
        public Object GetAllUserByName(string UserEmail)
        {
            var data = _UserService.GetUserByUserName(UserEmail);
            var json = JsonConvert.SerializeObject(data, Formatting.Indented,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                }
            );
            return json;
        }

        //GET All User
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetAllUsers")]
        public Object GetAllUsers()
        {
            var data = _UserService.GetAllUsers();
            var json = JsonConvert.SerializeObject(data, Formatting.Indented,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                }
            );
            return json;
        }
    }
}